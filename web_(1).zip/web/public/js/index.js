document.addEventListener('DOMContentLoaded',function(){
  var $navbarBurgers=Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'),0);
  if($navbarBurgers.length>0){
    $navbarBurgers.forEach(function($el){
      $el.addEventListener('click',function(){
        var target=$el.dataset.target;
        var $target=document.getElementById(target);
        $el.classList.toggle('is-active');
        $target.classList.toggle('is-active');
      });
    });
  }
});

$(document).ready(function(){
  $('.carousel').slick({
  slidesToShow: 1,
  autoplay: true,
  dots:true,
  centerMode: true,
  });
});

$(document).ready(function(){
  $('.new-product .columns').slick({
  slidesToShow: 1,
  autoplay: true,
  dots:true,
  centerMode: true,
  });
});

$(document).ready(function(){
  $(function(){
    $('a').click(function(){
      $('html, body').animate({
        scrollTop:$($(this).attr('href')).offset().top
      },1000);
      return false;
    });
  });
  $('.responsive-slider').slick({
    autoplay:true,
    autoplaySpeed:2000,
    infinite:true,
    speed:300,
    slidesToShow:4,
    slidesToScroll:1,
    responsive:[{
      breakpoint:1024,
      settings:{
        slidesToShow:6,
        slidesToScroll:1,
      }
    },
      {
        breakpoint:800,
        settings:{
          slidesToShow:3,
          slidesToScroll:2,
          dots:true,
          infinite:true,
        }
      },
      {
        breakpoint:600,
        settings:{
          slidesToShow:2,
          slidesToScroll:2,
          dots:true,
          infinite:true,
        }
      },
      {
        breakpoint:480,
        settings:{
          slidesToShow:1,
          slidesToScroll:1,
          dots:true,
          infinite:true,
          autoplay:true,
          autoplaySpeed:2000,
        }
      }
    ]}
  );
});
